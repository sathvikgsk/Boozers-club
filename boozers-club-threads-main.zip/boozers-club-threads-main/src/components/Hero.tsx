
import React from "react";
import { Link } from "react-router-dom";

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen flex items-center justify-center text-center px-4 md:px-8">
      {/* Background image with overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: "url('https://source.unsplash.com/1600x900/?fashion,streetwear')",
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-65 backdrop-blur-sm"></div>
      </div>
      
      {/* Pattern overlay (optional) */}
      <div className="absolute inset-0 z-0 bg-[url('https://st2.depositphotos.com/2511477/6362/v/450/depositphotos_63624603-stock-illustration-background-with-colorful-shopping-icons.jpg')] bg-center opacity-[0.12]"></div>
      
      {/* Content */}
      <div className="relative z-10 max-w-3xl mx-auto animate-fadeInUp">
        <h1 className="text-5xl md:text-7xl font-bold mb-4 text-brand-pink">
          BOOZER'S CLUB
        </h1>
        <p className="text-xl md:text-2xl text-white mb-8">
          Revolution in Fashion is Coming
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link
            to="/shop"
            className="bg-brand-pink hover:bg-brand-darkPink text-white py-3 px-8 rounded-full shadow-lg transition-all duration-300 font-medium"
          >
            Shop Collection
          </Link>
          <Link
            to="/contact"
            className="border-2 border-white text-white hover:bg-white hover:text-black py-3 px-8 rounded-full shadow-lg transition-all duration-300 font-medium"
          >
            Notify Me
          </Link>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          width="24" 
          height="24" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          className="text-white"
        >
          <path d="M12 5v14"></path>
          <path d="m19 12-7 7-7-7"></path>
        </svg>
      </div>
    </div>
  );
};

export default Hero;
