
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useCart } from "../contexts/CartContext";
import { useAuth } from "../contexts/AuthContext";
import { ShoppingBag, User, Menu, X } from "lucide-react";

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { totalItems } = useCart();
  const { isAuthenticated } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  
  const isHomePage = location.pathname === "/";
  
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <nav className={`flex justify-between items-center px-4 md:px-8 py-4 sticky top-0 z-50 ${
        isHomePage ? "bg-opacity-60 backdrop-blur-md bg-black" : "bg-brand-dark"
      }`}>
        <div className="flex items-center">
          {/* Mobile menu button */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden mr-4 text-white"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
          
          <Link to="/" className="text-2xl font-bold text-white">BOOZER'S CLUB</Link>
        </div>
        
        {/* Desktop Navigation Links */}
        <div className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-white hover:text-brand-pink transition-colors">Home</Link>
          <Link to="/shop" className="text-white hover:text-brand-pink transition-colors">Shop</Link>
          <Link to="/about" className="text-white hover:text-brand-pink transition-colors">About</Link>
          <Link to="/contact" className="text-white hover:text-brand-pink transition-colors">Contact</Link>
        </div>
        
        {/* User and Cart Links */}
        <div className="flex items-center space-x-4">
          <Link to={isAuthenticated ? "/account" : "/login"} className="text-white hover:text-brand-pink">
            <User className="w-6 h-6" />
          </Link>
          <Link to="/cart" className="text-white hover:text-brand-pink relative">
            <ShoppingBag className="w-6 h-6" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-brand-pink rounded-full w-5 h-5 flex items-center justify-center text-xs text-white">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </nav>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-brand-darker text-white py-4 px-6 z-40 absolute top-16 left-0 right-0">
          <div className="flex flex-col space-y-4">
            <Link 
              to="/" 
              className="py-2 hover:text-brand-pink"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/shop" 
              className="py-2 hover:text-brand-pink"
              onClick={() => setMobileMenuOpen(false)}
            >
              Shop
            </Link>
            <Link 
              to="/about" 
              className="py-2 hover:text-brand-pink"
              onClick={() => setMobileMenuOpen(false)}
            >
              About
            </Link>
            <Link 
              to="/contact" 
              className="py-2 hover:text-brand-pink"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </Link>
          </div>
        </div>
      )}
      
      {/* Main content */}
      <main className="flex-grow">
        {children}
      </main>
      
      {/* Footer */}
      <footer className="bg-brand-darker text-brand-gray py-8 px-4 md:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-brand-pink font-bold text-xl mb-4">BOOZER'S CLUB</h3>
              <p className="mb-4">Revolution in Fashion is Coming.</p>
              <p>We're not just a brand. We're a movement. Fashion that defies trends and creates culture.</p>
            </div>
            
            <div>
              <h3 className="text-white font-bold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link to="/" className="text-brand-gray hover:text-white transition-colors">Home</Link></li>
                <li><Link to="/shop" className="text-brand-gray hover:text-white transition-colors">Shop</Link></li>
                <li><Link to="/about" className="text-brand-gray hover:text-white transition-colors">About</Link></li>
                <li><Link to="/contact" className="text-brand-gray hover:text-white transition-colors">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-bold text-lg mb-4">Contact</h3>
              <p className="mb-2">Email: <a href="mailto:boozersclub@yahoo.com" className="text-brand-pink hover:text-white">boozersclub@yahoo.com</a></p>
              <p>Follow us on social media:</p>
              <div className="flex space-x-4 mt-2">
                <a href="#" className="text-brand-gray hover:text-brand-pink transition-colors">Instagram</a>
                <a href="#" className="text-brand-gray hover:text-brand-pink transition-colors">Twitter</a>
                <a href="#" className="text-brand-gray hover:text-brand-pink transition-colors">Facebook</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-6 text-center">
            <p className="text-brand-gray mb-2">GUNS DON'T NEED AGREEMENTS!</p>
            <p>&copy; {new Date().getFullYear()} BOOZER'S CLUB. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
