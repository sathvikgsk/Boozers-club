
import React from "react";
import { Link } from "react-router-dom";
import { Product } from "../contexts/ProductsContext";

type ProductCardProps = {
  product: Product;
};

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <Link to={`/product/${product.id}`} className="group">
      <div className="bg-brand-darker rounded-xl overflow-hidden shadow-lg transition-transform duration-300 group-hover:transform group-hover:translate-y-[-8px] group-hover:shadow-xl">
        <div className="relative overflow-hidden h-64">
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          
          {(product.featured || product.newArrival) && (
            <div className="absolute top-0 right-0 m-2">
              {product.featured && (
                <span className="bg-brand-pink text-white px-2 py-1 text-xs font-medium rounded">
                  Featured
                </span>
              )}
              {product.newArrival && (
                <span className="bg-blue-500 text-white px-2 py-1 text-xs font-medium rounded ml-1">
                  New Arrival
                </span>
              )}
            </div>
          )}
        </div>
        
        <div className="p-4">
          <h3 className="font-bold text-white text-lg mb-1">
            {product.name}
          </h3>
          
          <div className="flex justify-between items-center mt-2">
            <p className="font-medium text-brand-pink">
              ₹{product.price.toFixed(2)}
            </p>
            
            <div className="text-brand-gray text-sm">
              {product.sizes.length > 1
                ? `${product.sizes[0]}-${product.sizes[product.sizes.length - 1]}`
                : product.sizes[0]}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
