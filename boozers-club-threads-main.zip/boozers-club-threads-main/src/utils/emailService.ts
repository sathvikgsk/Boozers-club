
import emailjs from "emailjs-com";

// Initialize EmailJS
// Replace these with your actual EmailJS credentials
const SERVICE_ID = "YOUR_SERVICE_ID";
const USER_ID = "YOUR_USER_ID";

export const EMAIL_TEMPLATES = {
  REGISTRATION: "registration_template",
  ORDER_CONFIRMATION: "order_confirmation",
  CONTACT_FORM: "contact_form"
};

export const sendEmail = async (
  templateId: string,
  templateParams: Record<string, unknown>
) => {
  try {
    // Make sure to include the owner's email as recipient
    const params = {
      ...templateParams,
      to_email: "boozersclub@yahoo.com"
    };
    
    const response = await emailjs.send(SERVICE_ID, templateId, params, USER_ID);
    return { success: true, response };
  } catch (error) {
    console.error("Error sending email:", error);
    return { success: false, error };
  }
};

/**
 * Send notification about new user registration
 */
export const sendRegistrationNotification = (user: { name: string; email: string }) => {
  return sendEmail(EMAIL_TEMPLATES.REGISTRATION, {
    user_name: user.name,
    user_email: user.email,
    message: `New user registration: ${user.name} (${user.email}) has registered on Boozer's Club.`
  });
};

/**
 * Send order confirmation
 */
export const sendOrderNotification = (
  order: {
    id: string;
    items: Array<{ name: string; size: string; quantity: number; price: number }>;
    total: number;
  },
  customer: {
    name: string;
    email: string;
    address: string;
    phone: string;
  }
) => {
  return sendEmail(EMAIL_TEMPLATES.ORDER_CONFIRMATION, {
    order_id: order.id,
    customer_name: customer.name,
    customer_email: customer.email,
    order_details: order.items.map(item => `${item.name} (${item.size}) x${item.quantity} - $${item.price.toFixed(2)}`).join(", "),
    total: `$${order.total.toFixed(2)}`,
    shipping_address: customer.address,
    phone: customer.phone
  });
};

/**
 * Send contact form submission
 */
export const sendContactFormNotification = (
  form: {
    name: string;
    email: string;
    subject: string;
    message: string;
  }
) => {
  return sendEmail(EMAIL_TEMPLATES.CONTACT_FORM, {
    from_name: form.name,
    from_email: form.email,
    subject: form.subject,
    message: form.message
  });
};
