
import React from "react";
import Layout from "../components/Layout";
import { 
  Users, 
  Award, 
  Heart, 
  Lightbulb, 
  Globe, 
  ArrowRight
} from "lucide-react";
import { Link } from "react-router-dom";

const About: React.FC = () => {
  return (
    <Layout>
      {/* Hero section */}
      <section className="relative bg-black py-24">
        <div className="absolute inset-0 opacity-40 bg-[url('https://images.unsplash.com/photo-1580657018950-c7f7d6a6d990?q=80&w=1470&auto=format&fit=crop')] bg-cover bg-center"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">Our Story</h1>
          <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto">
            BOOZER'S CLUB isn't just a brand — it's a revolution, a movement, a statement.
          </p>
        </div>
      </section>

      {/* Mission section */}
      <section className="py-16 px-4 bg-brand-darker">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-brand-pink mb-6">Our Mission</h2>
              <p className="text-white text-lg mb-4">
                We're here to disrupt the fashion industry by creating clothing that empowers self-expression and challenges the status quo.
              </p>
              <p className="text-white text-lg mb-6">
                Every piece we create isn't just about looking good – it's about making a statement, about wearing your beliefs proudly and unapologetically.
              </p>
              <div className="flex items-center text-brand-pink">
                <Heart className="mr-2" size={20} />
                <span className="font-semibold">GUNS DON'T NEED AGREEMENTS!</span>
              </div>
            </div>
            <div className="relative h-80 md:h-96">
              <div className="absolute inset-0 bg-brand-dark rounded-lg overflow-hidden transform rotate-3 shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=1470&auto=format&fit=crop" 
                  alt="Fashion model" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values section */}
      <section className="py-16 px-4 bg-brand-dark">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-brand-pink mb-12 text-center">Our Values</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-brand-darker p-8 rounded-lg hover:transform hover:scale-105 transition-transform duration-300">
              <div className="bg-brand-pink rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <Award className="text-white" size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Quality First</h3>
              <p className="text-gray-300">
                We never compromise on quality. Each piece is crafted with premium materials and attention to detail.
              </p>
            </div>
            
            <div className="bg-brand-darker p-8 rounded-lg hover:transform hover:scale-105 transition-transform duration-300">
              <div className="bg-brand-pink rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <Lightbulb className="text-white" size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Innovation</h3>
              <p className="text-gray-300">
                We're not followers – we're trendsetters. Our designs push boundaries and challenge conventions.
              </p>
            </div>
            
            <div className="bg-brand-darker p-8 rounded-lg hover:transform hover:scale-105 transition-transform duration-300">
              <div className="bg-brand-pink rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <Globe className="text-white" size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Global Impact</h3>
              <p className="text-gray-300">
                Our community spans across borders. We're building a worldwide movement of fashion revolutionaries.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team section */}
      <section className="py-16 px-4 bg-brand-darker">
        <div className="container mx-auto max-w-6xl">
          <div className="flex justify-between items-end mb-12">
            <h2 className="text-3xl font-bold text-brand-pink">Meet The Crew</h2>
            <div className="hidden md:flex items-center text-white hover:text-brand-pink transition-colors cursor-pointer">
              <span className="mr-2">Meet full team</span>
              <ArrowRight size={20} />
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <div className="group">
              <div className="relative overflow-hidden rounded-lg mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=1374&auto=format&fit=crop" 
                  alt="Team member" 
                  className="w-full aspect-square object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4">
                    <p className="text-white font-medium">Creative Director</p>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-bold text-white">Alex Maxwell</h3>
            </div>
            
            <div className="group">
              <div className="relative overflow-hidden rounded-lg mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1361&auto=format&fit=crop" 
                  alt="Team member" 
                  className="w-full aspect-square object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4">
                    <p className="text-white font-medium">Head Designer</p>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-bold text-white">Jamie Chen</h3>
            </div>
            
            <div className="group">
              <div className="relative overflow-hidden rounded-lg mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1374&auto=format&fit=crop" 
                  alt="Team member" 
                  className="w-full aspect-square object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4">
                    <p className="text-white font-medium">Marketing Lead</p>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-bold text-white">Raj Kumar</h3>
            </div>
            
            <div className="group">
              <div className="relative overflow-hidden rounded-lg mb-4">
                <img 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1374&auto=format&fit=crop" 
                  alt="Team member" 
                  className="w-full aspect-square object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4">
                    <p className="text-white font-medium">Product Manager</p>
                  </div>
                </div>
              </div>
              <h3 className="text-xl font-bold text-white">Sofia Lopez</h3>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-brand-dark">
        <div className="container mx-auto max-w-6xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-pink mb-8">Join The Revolution</h2>
          <p className="text-white text-xl max-w-3xl mx-auto mb-10">
            Be part of something bigger. Join the BOOZER'S CLUB community and help us redefine fashion.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/shop"
              className="inline-block bg-brand-pink hover:bg-opacity-90 text-white font-bold py-3 px-8 rounded-md transition-colors"
            >
              Shop Collection
            </Link>
            <Link
              to="/contact"
              className="inline-block border-2 border-white text-white hover:bg-white hover:text-brand-darker font-bold py-3 px-8 rounded-md transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
