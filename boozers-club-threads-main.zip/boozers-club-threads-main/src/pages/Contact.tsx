import React, { useState } from "react";
import Layout from "../components/Layout";
import { sendContactFormNotification } from "../utils/emailService";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  
  const [status, setStatus] = useState<{
    submitted: boolean;
    success: boolean;
    message: string;
  }>({
    submitted: false,
    success: false,
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus({ submitted: true, success: false, message: "Sending your message..." });

    try {
      const result = await sendContactFormNotification(formData);
      
      if (result.success) {
        setStatus({
          submitted: true,
          success: true,
          message: "Thank you! Your message has been sent successfully.",
        });
        setFormData({ name: "", email: "", subject: "", message: "" });
      } else {
        setStatus({
          submitted: true,
          success: false,
          message: "Something went wrong. Please try again later.",
        });
      }
    } catch (error) {
      setStatus({
        submitted: true,
        success: false,
        message: "Something went wrong. Please try again later.",
      });
    }
  };

  return (
    <Layout>
      <div className="bg-brand-dark py-16 px-4 md:px-8">
        <div className="container mx-auto max-w-4xl">
          <h1 className="text-4xl font-bold text-brand-pink mb-4">Contact Us</h1>
          <p className="text-white text-lg mb-8">
            Have questions about our products or want to collaborate? Send us a message!
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-brand-darker p-6 rounded-lg">
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label htmlFor="name" className="block text-white mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full py-2 px-4 bg-gray-800 text-white rounded border border-gray-700 focus:outline-none focus:border-brand-pink"
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="email" className="block text-white mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full py-2 px-4 bg-gray-800 text-white rounded border border-gray-700 focus:outline-none focus:border-brand-pink"
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="subject" className="block text-white mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full py-2 px-4 bg-gray-800 text-white rounded border border-gray-700 focus:outline-none focus:border-brand-pink"
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="message" className="block text-white mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full py-2 px-4 bg-gray-800 text-white rounded border border-gray-700 focus:outline-none focus:border-brand-pink"
                  />
                </div>

                <button
                  type="submit"
                  disabled={status.submitted && !status.success}
                  className="w-full py-3 px-6 bg-brand-pink hover:bg-brand-darkPink text-white font-semibold rounded transition-colors"
                >
                  Send Message
                </button>

                {status.submitted && (
                  <div
                    className={`mt-4 p-4 rounded ${
                      status.success ? "bg-green-900" : "bg-red-900"
                    }`}
                  >
                    <p className="text-white">{status.message}</p>
                  </div>
                )}
              </form>
            </div>

            <div>
              <div className="bg-brand-darker p-6 rounded-lg mb-6">
                <h2 className="text-xl font-bold text-white mb-4">Contact Information</h2>
                <p className="text-gray-300 mb-4">
                  Got questions or need assistance? Reach out to us using the contact information below.
                </p>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-brand-pink font-medium mb-1">Email</h3>
                    <a
                      href="mailto:boozersclub@yahoo.com"
                      className="text-white hover:text-brand-pink transition-colors"
                    >
                      boozersclub@yahoo.com
                    </a>
                  </div>
                  <div>
                    <h3 className="text-brand-pink font-medium mb-1">Social Media</h3>
                    <div className="flex space-x-4">
                      <a href="#" className="text-gray-400 hover:text-white transition-colors">
                        Instagram
                      </a>
                      <a href="#" className="text-gray-400 hover:text-white transition-colors">
                        Facebook
                      </a>
                      <a href="#" className="text-gray-400 hover:text-white transition-colors">
                        Twitter
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-brand-darker p-6 rounded-lg">
                <h2 className="text-xl font-bold text-white mb-4">Store Hours</h2>
                <ul className="space-y-2">
                  <li className="flex justify-between">
                    <span className="text-gray-400">Online Store</span>
                    <span className="text-white">AVAILABLE 24/7</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Contact;
