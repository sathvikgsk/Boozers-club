
import React from "react";
import Layout from "../components/Layout";
import ProductCard from "../components/ProductCard";
import { useFavorites } from "../contexts/FavoritesContext";
import { Link } from "react-router-dom";
import { Heart, ShoppingBag, ArrowRight } from "lucide-react";

const Favorites: React.FC = () => {
  const { favorites, removeFromFavorites } = useFavorites();

  if (favorites.length === 0) {
    return (
      <Layout>
        <div className="bg-brand-dark py-16 px-4 md:px-8 min-h-[70vh] flex flex-col items-center justify-center">
          <Heart className="text-gray-400 w-16 h-16 mb-4" />
          <h1 className="text-3xl font-bold text-white mb-4">Your Favorites List is Empty</h1>
          <p className="text-gray-400 mb-8 text-center max-w-md">
            You haven't added any items to your favorites yet.
          </p>
          <Link
            to="/shop"
            className="bg-brand-pink hover:bg-brand-darkPink text-white py-3 px-8 rounded-full transition-colors flex items-center gap-2"
          >
            Explore Products <ArrowRight size={16} />
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="bg-brand-dark py-12 px-4 md:px-8">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-white mb-8">Your Favorites</h1>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {favorites.map((product) => (
              <div key={product.id} className="relative">
                <button
                  onClick={() => removeFromFavorites(product.id)}
                  className="absolute top-2 right-2 z-10 bg-gray-900 p-2 rounded-full hover:bg-red-600 transition-colors"
                  title="Remove from favorites"
                >
                  <Heart className="h-5 w-5 text-white" fill="white" />
                </button>
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Favorites;
