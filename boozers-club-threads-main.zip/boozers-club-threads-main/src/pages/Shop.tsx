
import React, { useState } from "react";
import Layout from "../components/Layout";
import ProductCard from "../components/ProductCard";
import { useProducts } from "../contexts/ProductsContext";
import { Filter, Search } from "lucide-react";

const Shop: React.FC = () => {
  const { products } = useProducts();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);
  
  // Get unique categories from products
  const categories = ["all", ...new Set(products.flatMap(product => product.categories))];
  
  // Filter products based on search and category
  const filteredProducts = products.filter(product => {
    // Filter by search query
    const matchesSearch = searchQuery
      ? product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
      
    // Filter by category (skip if "all" is selected)
    const matchesCategory = 
      selectedCategory === "all" || product.categories.includes(selectedCategory);
      
    return matchesSearch && matchesCategory;
  });

  return (
    <Layout>
      <div className="bg-brand-dark py-12 px-4 md:px-8">
        <div className="container mx-auto">
          <h1 className="text-4xl font-bold text-brand-pink mb-8">Shop Collection</h1>
          
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            {/* Search input */}
            <div className="relative flex-grow">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full py-3 pl-12 pr-4 rounded-lg bg-gray-800 text-white border border-gray-700 focus:outline-none focus:border-brand-pink"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            
            {/* Filters toggle (mobile) */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="md:hidden flex items-center justify-center gap-2 py-3 px-4 bg-gray-800 text-white rounded-lg border border-gray-700"
            >
              <Filter size={18} />
              Filters
            </button>
          </div>
          
          <div className="flex flex-col md:flex-row gap-8">
            {/* Filters sidebar */}
            <aside className={`${showFilters ? 'block' : 'hidden'} md:block w-full md:w-64 bg-brand-darker p-4 rounded-lg`}>
              <h2 className="text-xl font-bold text-white mb-4">Categories</h2>
              <ul className="space-y-2">
                {categories.map((category) => (
                  <li key={category}>
                    <button
                      onClick={() => setSelectedCategory(category)}
                      className={`py-2 px-4 w-full text-left rounded ${
                        selectedCategory === category
                          ? "bg-brand-pink text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </button>
                  </li>
                ))}
              </ul>
            </aside>
            
            {/* Products grid */}
            <div className="flex-grow">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))
                ) : (
                  <div className="col-span-full text-center py-12">
                    <p className="text-xl text-gray-400">No products found.</p>
                    <p className="mt-2 text-gray-500">Try adjusting your search or filters.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Shop;
