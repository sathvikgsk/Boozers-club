
import React from "react";
import Layout from "../components/Layout";
import Hero from "../components/Hero";
import ProductCard from "../components/ProductCard";
import { useProducts } from "../contexts/ProductsContext";
import { Link } from "react-router-dom";

const Index: React.FC = () => {
  const { getNewArrivals } = useProducts();
  const newArrivals = getNewArrivals();

  return (
    <Layout>
      <Hero />

      {/* About Section */}
      <section id="about" className="py-16 px-4 md:px-8 bg-brand-dark">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8 text-brand-pink">About Us</h2>
          <p className="text-xl text-white max-w-3xl mx-auto mb-8">
            We're not just a brand. We're a movement. Fashion that defies trends and creates culture.
          </p>
          <Link
            to="/about"
            className="inline-block py-2 px-4 text-white border-b-2 border-brand-pink hover:text-brand-pink transition-colors"
          >
            Learn More About BOOZER'S CLUB
          </Link>
        </div>
      </section>

      {/* New Arrivals Section */}
      <section className="py-16 px-4 md:px-8 bg-brand-darker">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-brand-pink">New Arrivals</h2>
            <Link
              to="/shop"
              className="text-white hover:text-brand-pink transition-colors flex items-center"
            >
              View All 
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="ml-1"
              >
                <path d="M5 12h14"></path>
                <path d="m12 5 7 7-7 7"></path>
              </svg>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {newArrivals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
