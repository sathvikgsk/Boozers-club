
import React from "react";
import Layout from "../components/Layout";
import { useCart } from "../contexts/CartContext";
import { Link } from "react-router-dom";
import { Trash2, ShoppingBag, ArrowRight, Heart } from "lucide-react";

const Cart: React.FC = () => {
  const { items, removeItem, updateQuantity, totalItems, totalPrice } = useCart();

  if (items.length === 0) {
    return (
      <Layout>
        <div className="bg-brand-dark py-16 px-4 md:px-8 min-h-[70vh] flex flex-col items-center justify-center">
          <ShoppingBag className="text-gray-400 w-16 h-16 mb-4" />
          <h1 className="text-3xl font-bold text-white mb-4">Your Cart is Empty</h1>
          <p className="text-gray-400 mb-8 text-center max-w-md">
            Looks like you haven't added any products to your cart yet.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/shop"
              className="bg-brand-pink hover:bg-brand-darkPink text-white py-3 px-8 rounded-full transition-colors flex items-center gap-2"
            >
              Start Shopping <ArrowRight size={16} />
            </Link>
            <Link
              to="/favorites"
              className="bg-transparent border border-gray-600 hover:border-gray-400 text-white py-3 px-8 rounded-full transition-colors flex items-center gap-2"
            >
              View Your Favorites <Heart size={16} />
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="bg-brand-dark py-12 px-4 md:px-8">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-white mb-8">Shopping Cart</h1>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Cart Items */}
            <div className="lg:w-2/3">
              {/* Headers on desktop */}
              <div className="hidden md:grid md:grid-cols-12 gap-4 pb-4 border-b border-gray-800 text-gray-400 font-medium">
                <div className="md:col-span-6">Product</div>
                <div className="md:col-span-2 text-center">Price</div>
                <div className="md:col-span-2 text-center">Quantity</div>
                <div className="md:col-span-2 text-right">Total</div>
              </div>

              {/* Cart Items */}
              <div className="space-y-4 mt-4">
                {items.map((item) => (
                  <div
                    key={`${item.id}-${item.size}`}
                    className="grid grid-cols-12 gap-4 py-4 border-b border-gray-800"
                  >
                    {/* Product Info */}
                    <div className="col-span-12 md:col-span-6 flex gap-4">
                      <div className="w-20 h-20 bg-brand-darker rounded overflow-hidden">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-medium text-white">{item.name}</h3>
                        <p className="text-gray-400 text-sm">Size: {item.size}</p>
                        <button
                          onClick={() => removeItem(item.id, item.size)}
                          className="text-red-500 flex items-center gap-1 text-sm mt-2 hover:text-red-400"
                        >
                          <Trash2 size={14} />
                          Remove
                        </button>
                        {/* Mobile price */}
                        <p className="md:hidden text-brand-pink font-medium mt-2">
                          ${item.price.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    {/* Price - Desktop */}
                    <div className="hidden md:flex md:col-span-2 items-center justify-center">
                      <p className="text-brand-pink font-medium">
                        ${item.price.toFixed(2)}
                      </p>
                    </div>

                    {/* Quantity */}
                    <div className="col-span-8 md:col-span-2 flex md:justify-center items-center">
                      <div className="flex">
                        <button
                          onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)}
                          className="w-8 h-8 flex items-center justify-center bg-gray-800 text-white rounded-l"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) =>
                            updateQuantity(
                              item.id,
                              item.size,
                              Math.max(1, parseInt(e.target.value) || 1)
                            )
                          }
                          className="w-12 h-8 text-center bg-gray-800 text-white border-x border-gray-700"
                        />
                        <button
                          onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center bg-gray-800 text-white rounded-r"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Total Price */}
                    <div className="col-span-4 md:col-span-2 flex items-center justify-end">
                      <p className="font-medium text-white">
                        ${(item.price * item.quantity).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:w-1/3">
              <div className="bg-brand-darker p-6 rounded-lg">
                <h2 className="text-xl font-bold text-white mb-4">Order Summary</h2>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between">
                    <p className="text-gray-400">Subtotal</p>
                    <p className="text-white">${totalPrice.toFixed(2)}</p>
                  </div>
                  <div className="flex justify-between">
                    <p className="text-gray-400">Shipping</p>
                    <p className="text-white">Calculated at checkout</p>
                  </div>
                  <div className="border-t border-gray-800 pt-3 flex justify-between">
                    <p className="font-medium text-white">Total</p>
                    <p className="font-medium text-brand-pink text-xl">
                      ${totalPrice.toFixed(2)}
                    </p>
                  </div>
                </div>

                <Link
                  to="/checkout"
                  className="block w-full py-3 px-4 bg-brand-pink hover:bg-brand-darkPink text-white font-medium rounded text-center transition-colors"
                >
                  Proceed to Checkout
                </Link>

                <div className="mt-4 flex gap-3">
                  <Link
                    to="/shop"
                    className="flex-1 py-3 px-4 border border-gray-700 hover:border-gray-600 text-white text-center rounded transition-colors"
                  >
                    Continue Shopping
                  </Link>
                  <Link
                    to="/favorites"
                    className="flex-1 py-3 px-4 border border-gray-700 hover:border-gray-600 text-white text-center rounded transition-colors flex items-center justify-center gap-1"
                  >
                    <Heart size={16} /> Favorites
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Cart;
