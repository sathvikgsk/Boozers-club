
import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { useProducts } from "../contexts/ProductsContext";
import { useCart } from "../contexts/CartContext";
import { useFavorites } from "../contexts/FavoritesContext";
import { Heart, Share2 } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getProduct } = useProducts();
  const { addItem } = useCart();
  const { addToFavorites, removeFromFavorites, isFavorite } = useFavorites();
  
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const product = getProduct(id || "");
  
  if (!product) {
    return (
      <Layout>
        <div className="container mx-auto py-16 px-4">
          <h1 className="text-3xl font-bold text-white mb-4">Product Not Found</h1>
          <p className="text-gray-400 mb-8">The product you're looking for doesn't exist or has been removed.</p>
          <button 
            onClick={() => navigate("/shop")}
            className="bg-brand-pink hover:bg-brand-darkPink text-white py-2 px-6 rounded-lg transition-colors"
          >
            Return to Shop
          </button>
        </div>
      </Layout>
    );
  }
  
  const handleAddToCart = () => {
    if (!selectedSize) {
      setError("Please select a size");
      return;
    }
    
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: selectedSize
    });
    
    setError(null);
    toast({
      title: "Added to cart",
      description: `${product.name} (${selectedSize}) has been added to your cart.`,
    });
  };

  const handleFavoriteToggle = () => {
    if (isFavorite(product.id)) {
      removeFromFavorites(product.id);
      toast({
        title: "Removed from favorites",
        description: `${product.name} has been removed from your favorites.`,
      });
    } else {
      addToFavorites(product);
      toast({
        title: "Added to favorites",
        description: `${product.name} has been added to your favorites.`,
      });
    }
  };

  return (
    <Layout>
      <div className="bg-brand-dark py-12 px-4 md:px-8">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Product Images */}
            <div className="md:w-1/2">
              <div className="mb-4 bg-brand-darker rounded-lg overflow-hidden">
                <img 
                  src={product.images[currentImageIndex]} 
                  alt={product.name} 
                  className="w-full h-full object-cover aspect-square"
                />
              </div>
              
              {/* Thumbnails */}
              {product.images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto py-2">
                  {product.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-16 h-16 rounded-md overflow-hidden flex-shrink-0 border-2 ${
                        currentImageIndex === index ? "border-brand-pink" : "border-transparent"
                      }`}
                    >
                      <img
                        src={image}
                        alt={`Thumbnail ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            {/* Product Info */}
            <div className="md:w-1/2">
              <h1 className="text-3xl font-bold text-white mb-2">{product.name}</h1>
              <p className="text-2xl font-bold text-brand-pink mb-4">₹{product.price.toFixed(2)}</p>
              
              <p className="text-gray-300 mb-6">{product.description}</p>
              
              {/* Size Selection */}
              <div className="mb-6">
                <h3 className="text-white font-semibold mb-2">Size</h3>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`w-12 h-10 flex items-center justify-center rounded border ${
                        selectedSize === size
                          ? "border-brand-pink bg-brand-pink bg-opacity-20 text-white"
                          : "border-gray-600 text-gray-300 hover:border-gray-400"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
                {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
              </div>
              
              {/* Quantity */}
              <div className="mb-6">
                <h3 className="text-white font-semibold mb-2">Quantity</h3>
                <div className="flex items-center">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 flex items-center justify-center bg-gray-800 text-white rounded-l"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-16 h-10 text-center bg-gray-800 text-white border-x border-gray-700"
                  />
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 flex items-center justify-center bg-gray-800 text-white rounded-r"
                  >
                    +
                  </button>
                </div>
              </div>
              
              {/* Add to Cart Button */}
              <div className="flex gap-4 mb-6">
                <button
                  onClick={handleAddToCart}
                  className="flex-grow py-3 px-6 bg-brand-pink hover:bg-brand-darkPink text-white font-semibold rounded-lg transition-colors"
                >
                  Add to Cart
                </button>
                <button 
                  onClick={handleFavoriteToggle}
                  className={`w-12 h-12 flex items-center justify-center ${
                    isFavorite(product.id)
                      ? "bg-brand-pink hover:bg-brand-darkPink text-white"
                      : "bg-gray-800 hover:bg-gray-700 text-white"
                  } rounded-lg transition-colors`}
                >
                  <Heart size={20} fill={isFavorite(product.id) ? "white" : "none"} />
                </button>
                <button className="w-12 h-12 flex items-center justify-center bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors">
                  <Share2 size={20} />
                </button>
              </div>
              
              {/* Additional Info */}
              <div className="border-t border-gray-800 pt-4">
                <p className="text-gray-400 text-sm">
                  <span className="font-semibold text-gray-300">Categories:</span>{" "}
                  {product.categories.map((c) => c.charAt(0).toUpperCase() + c.slice(1)).join(", ")}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProductDetail;
