
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { useCart } from "../contexts/CartContext";
import { useForm } from "react-hook-form";
import { toast } from "@/components/ui/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ShoppingBag, CreditCard, ArrowRight, CheckCircle } from "lucide-react";
import { ShippingDetails } from "../contexts/CartContext";

const Checkout: React.FC = () => {
  const { items, totalPrice, checkout, clearCart } = useCart();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState<"shipping" | "payment" | "confirmation">("shipping");

  const form = useForm<ShippingDetails>({
    defaultValues: {
      fullName: "",
      email: "",
      address: "",
      city: "",
      state: "",
      postalCode: "",
      country: "",
      phone: "",
    }
  });

  // Handle shipping form submission
  const onSubmitShipping = (data: ShippingDetails) => {
    setStep("payment");
  };

  // Handle payment form submission
  const onSubmitPayment = async (paymentData: any) => {
    setIsSubmitting(true);
    try {
      const success = await checkout(form.getValues());
      if (success) {
        setStep("confirmation");
        clearCart();
      } else {
        toast({
          variant: "destructive",
          title: "Payment Failed",
          description: "There was an issue processing your payment. Please try again.",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Payment Error",
        description: "An unexpected error occurred. Please try again later.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (items.length === 0 && step !== "confirmation") {
    navigate("/cart");
    return null;
  }

  return (
    <Layout>
      <div className="bg-brand-dark py-12 px-4 md:px-8">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-white mb-8">Checkout</h1>

          {/* Checkout Steps Indicator */}
          <div className="flex justify-center mb-8">
            <div className="flex items-center max-w-md w-full">
              <div className={`flex flex-col items-center flex-1 ${step === "shipping" ? "text-brand-pink" : "text-gray-400"}`}>
                <div className={`w-10 h-10 flex items-center justify-center rounded-full border-2 ${step === "shipping" ? "border-brand-pink bg-brand-pink bg-opacity-20" : "border-gray-600"}`}>
                  1
                </div>
                <span className="mt-2 text-sm">Shipping</span>
              </div>
              <div className={`flex-1 h-0.5 ${step === "shipping" ? "bg-gray-600" : "bg-brand-pink"}`} />
              <div className={`flex flex-col items-center flex-1 ${step === "payment" ? "text-brand-pink" : "text-gray-400"}`}>
                <div className={`w-10 h-10 flex items-center justify-center rounded-full border-2 ${step === "payment" ? "border-brand-pink bg-brand-pink bg-opacity-20" : "border-gray-600"}`}>
                  2
                </div>
                <span className="mt-2 text-sm">Payment</span>
              </div>
              <div className={`flex-1 h-0.5 ${step === "confirmation" ? "bg-brand-pink" : "bg-gray-600"}`} />
              <div className={`flex flex-col items-center flex-1 ${step === "confirmation" ? "text-brand-pink" : "text-gray-400"}`}>
                <div className={`w-10 h-10 flex items-center justify-center rounded-full border-2 ${step === "confirmation" ? "border-brand-pink bg-brand-pink bg-opacity-20" : "border-gray-600"}`}>
                  3
                </div>
                <span className="mt-2 text-sm">Confirmation</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main Content */}
            <div className="lg:w-2/3">
              {/* Shipping Information Form */}
              {step === "shipping" && (
                <div className="bg-brand-darker p-6 rounded-lg mb-6">
                  <h2 className="text-xl font-bold text-white mb-4">Shipping Information</h2>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmitShipping)} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="fullName"
                          rules={{ required: "Name is required" }}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Full Name</FormLabel>
                              <FormControl>
                                <Input {...field} className="bg-gray-800 border-gray-700 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="email"
                          rules={{ 
                            required: "Email is required",
                            pattern: {
                              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                              message: "Invalid email address"
                            }
                          }}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Email</FormLabel>
                              <FormControl>
                                <Input {...field} type="email" className="bg-gray-800 border-gray-700 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="address"
                        rules={{ required: "Address is required" }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Address</FormLabel>
                            <FormControl>
                              <Input {...field} className="bg-gray-800 border-gray-700 text-white" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="city"
                          rules={{ required: "City is required" }}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">City</FormLabel>
                              <FormControl>
                                <Input {...field} className="bg-gray-800 border-gray-700 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="state"
                          rules={{ required: "State is required" }}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">State/Province</FormLabel>
                              <FormControl>
                                <Input {...field} className="bg-gray-800 border-gray-700 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="postalCode"
                          rules={{ required: "Postal code is required" }}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Postal/ZIP Code</FormLabel>
                              <FormControl>
                                <Input {...field} className="bg-gray-800 border-gray-700 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="country"
                          rules={{ required: "Country is required" }}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-200">Country</FormLabel>
                              <FormControl>
                                <Input {...field} className="bg-gray-800 border-gray-700 text-white" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="phone"
                        rules={{ required: "Phone number is required" }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-200">Phone Number</FormLabel>
                            <FormControl>
                              <Input {...field} type="tel" className="bg-gray-800 border-gray-700 text-white" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="pt-4">
                        <Button type="submit" className="w-full py-6 bg-brand-pink hover:bg-brand-darkPink text-white">
                          Continue to Payment <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </form>
                  </Form>
                </div>
              )}

              {/* Payment Information Form */}
              {step === "payment" && (
                <div className="bg-brand-darker p-6 rounded-lg mb-6">
                  <h2 className="text-xl font-bold text-white mb-4">Payment Information</h2>
                  
                  <form onSubmit={(e) => { e.preventDefault(); onSubmitPayment({}); }} className="space-y-4">
                    <div>
                      <label className="block text-gray-200 mb-2">Card Number</label>
                      <Input 
                        type="text"
                        placeholder="1234 5678 9012 3456"
                        className="bg-gray-800 border-gray-700 text-white w-full"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-200 mb-2">Expiration Date</label>
                        <Input 
                          type="text"
                          placeholder="MM/YY"
                          className="bg-gray-800 border-gray-700 text-white w-full"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-gray-200 mb-2">CVV</label>
                        <Input 
                          type="text"
                          placeholder="123"
                          className="bg-gray-800 border-gray-700 text-white w-full"
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-gray-200 mb-2">Cardholder Name</label>
                      <Input 
                        type="text"
                        placeholder="John Doe"
                        className="bg-gray-800 border-gray-700 text-white w-full"
                        required
                      />
                    </div>

                    <div className="flex gap-4 pt-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setStep("shipping")}
                        className="flex-1 py-6"
                      >
                        Back
                      </Button>
                      <Button 
                        type="submit" 
                        className="flex-1 py-6 bg-brand-pink hover:bg-brand-darkPink text-white"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? "Processing..." : (
                          <>
                            Complete Order <CreditCard className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </div>
              )}

              {/* Order Confirmation */}
              {step === "confirmation" && (
                <div className="bg-brand-darker p-6 rounded-lg mb-6 text-center">
                  <div className="flex justify-center mb-4">
                    <CheckCircle className="text-green-500 w-20 h-20" />
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-4">Order Confirmed!</h2>
                  <p className="text-gray-300 mb-6">
                    Thank you for your purchase. Your order has been received and is being processed.
                    We've sent a confirmation email to {form.getValues().email}.
                  </p>
                  <Button 
                    onClick={() => navigate("/")} 
                    className="bg-brand-pink hover:bg-brand-darkPink text-white"
                  >
                    Continue Shopping
                  </Button>
                </div>
              )}
            </div>
            
            {/* Order Summary */}
            {step !== "confirmation" && (
              <div className="lg:w-1/3">
                <div className="bg-brand-darker p-6 rounded-lg sticky top-4">
                  <h2 className="text-xl font-bold text-white mb-4">Order Summary</h2>
                  
                  <div className="mb-4 max-h-80 overflow-y-auto pr-2">
                    {items.map((item) => (
                      <div key={`${item.id}-${item.size}`} className="flex gap-3 py-3 border-b border-gray-800">
                        <div className="w-16 h-16 bg-gray-800 rounded overflow-hidden">
                          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-grow">
                          <p className="text-white font-medium">{item.name}</p>
                          <p className="text-gray-400 text-sm">Size: {item.size}</p>
                          <div className="flex justify-between mt-1">
                            <p className="text-gray-400 text-sm">Qty: {item.quantity}</p>
                            <p className="text-brand-pink">${(item.price * item.quantity).toFixed(2)}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-3 pt-3 border-t border-gray-800">
                    <div className="flex justify-between">
                      <p className="text-gray-400">Subtotal</p>
                      <p className="text-white">${totalPrice.toFixed(2)}</p>
                    </div>
                    <div className="flex justify-between">
                      <p className="text-gray-400">Shipping</p>
                      <p className="text-white">$5.99</p>
                    </div>
                    <div className="flex justify-between border-t border-gray-800 pt-3">
                      <p className="font-medium text-white">Total</p>
                      <p className="font-medium text-brand-pink text-xl">
                        ${(totalPrice + 5.99).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Checkout;
