
import React, { createContext, useContext, useState } from "react";

// Define types
export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  categories: string[];
  sizes: string[];
  availableColors?: string[];
  featured?: boolean;
  newArrival?: boolean;
};

type ProductsContextType = {
  products: Product[];
  getProduct: (id: string) => Product | undefined;
  getFeaturedProducts: () => Product[];
  getNewArrivals: () => Product[];
  getProductsByCategory: (category: string) => Product[];
  searchProducts: (query: string) => Product[];
};

// Create sample products - removing products with categories "hoodies", "accessories", or "headwear"
const sampleProducts: Product[] = [
  {
    id: "p1",
    name: "LIMITED DROP",
    description: "Bold statement tee with the iconic BOOZER'S CLUB logo. Limited edition from our first drop. Premium cotton for maximum comfort and style.",
    price: 2899, // Converted to INR
    images: [
      "https://img.freepik.com/free-photo/front-view-young-man-with-santa-hat-holding-shopping-bags-clipboard-standing-yellow-background_179666-19552.jpg",
      "https://img.freepik.com/free-photo/model-with-eyeglasses-looking-up_23-2148363165.jpg"
    ],
    categories: ["tshirts", "featured", "limited"],
    sizes: ["S", "M", "L", "XL"],
    featured: true
  },
  {
    id: "p2",
    name: "URBAN ESSENTIALS",
    description: "The perfect street style tee for any occasion. Features Urban Essentials print on high-quality cotton. Comfortable fit with stylish design.",
    price: 2499, // Converted to INR
    images: [
      "https://static.vecteezy.com/system/resources/thumbnails/027/215/665/small/a-fashionable-teenage-boy-wearing-a-black-longsleeve-and-glasses-poses-with-a-smile-against-a-blue-background-illuminated-by-neon-lights-representing-a-hi-free-photo.jpg",
      "https://img.freepik.com/free-photo/model-with-eyeglasses-looking-up_23-2148363165.jpg"
    ],
    categories: ["tshirts", "urban"],
    sizes: ["S", "M", "L", "XL"],
    featured: true,
    newArrival: true
  },
  {
    id: "p3",
    name: "EL-DORADO",
    description: "Redefining multi-classico style. Eye-catching El-Dorado graphic on premium fabric. Made for those who set trends, not follow them.",
    price: 2699, // Converted to INR
    images: [
      "https://static.vecteezy.com/system/resources/thumbnails/055/184/537/small/smiling-young-man-pointing-finger-at-copy-space-isolated-on-white-background-free-photo.jpeg",
      "https://img.freepik.com/free-photo/model-with-eyeglasses-looking-up_23-2148363165.jpg"
    ],
    categories: ["tshirts", "premium"],
    sizes: ["S", "M", "L", "XL"],
    newArrival: true
  },
  {
    id: "p4",
    name: "BOOZER'S CLASSIC TEE",
    description: "The essential BOOZER'S CLUB classic tee. Simple, clean design with our signature logo. Perfect for everyday wear.",
    price: 1999, // Converted to INR
    images: [
      "https://img.freepik.com/free-photo/man-with-hands-pockets_1187-1111.jpg",
      "https://img.freepik.com/free-photo/fashion-portrait-young-man-black-shirt-poses_186202-8496.jpg"
    ],
    categories: ["tshirts", "classic"],
    sizes: ["S", "M", "L", "XL", "XXL"],
  }
];

// Create the context
const ProductsContext = createContext<ProductsContextType | undefined>(undefined);

// Create provider component
export const ProductsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products] = useState<Product[]>(sampleProducts);

  // Get product by ID
  const getProduct = (id: string) => {
    return products.find((product) => product.id === id);
  };

  // Get featured products
  const getFeaturedProducts = () => {
    return products.filter((product) => product.featured);
  };

  // Get new arrivals
  const getNewArrivals = () => {
    return products.filter((product) => product.newArrival);
  };

  // Get products by category
  const getProductsByCategory = (category: string) => {
    return products.filter((product) => 
      product.categories.includes(category.toLowerCase())
    );
  };

  // Search products
  const searchProducts = (query: string) => {
    const lowercaseQuery = query.toLowerCase();
    return products.filter(
      (product) =>
        product.name.toLowerCase().includes(lowercaseQuery) ||
        product.description.toLowerCase().includes(lowercaseQuery) ||
        product.categories.some((cat) => cat.toLowerCase().includes(lowercaseQuery))
    );
  };

  const value = {
    products,
    getProduct,
    getFeaturedProducts,
    getNewArrivals,
    getProductsByCategory,
    searchProducts,
  };

  return <ProductsContext.Provider value={value}>{children}</ProductsContext.Provider>;
};

// Create a custom hook to use the products context
export const useProducts = () => {
  const context = useContext(ProductsContext);
  if (context === undefined) {
    throw new Error("useProducts must be used within a ProductsProvider");
  }
  return context;
};
