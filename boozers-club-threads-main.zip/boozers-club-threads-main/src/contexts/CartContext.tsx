
import React, { createContext, useContext, useState, useEffect } from "react";
import emailjs from "emailjs-com";
import { useAuth } from "./AuthContext";

// Define types
export type CartItem = {
  id: string;
  name: string;
  price: number;
  image: string;
  size: string;
  quantity: number;
};

type CartContextType = {
  items: CartItem[];
  addItem: (product: Omit<CartItem, "quantity">) => void;
  removeItem: (id: string, size: string) => void;
  updateQuantity: (id: string, size: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
  checkout: (shippingDetails: ShippingDetails) => Promise<boolean>;
};

export type ShippingDetails = {
  fullName: string;
  email: string;
  address: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string;
};

// Create the context
const CartContext = createContext<CartContextType | undefined>(undefined);

// Create provider component
export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const { user } = useAuth();
  
  // Load cart from localStorage on initial render
  useEffect(() => {
    const storedCart = localStorage.getItem("cart");
    if (storedCart) {
      setItems(JSON.parse(storedCart));
    }
  }, []);
  
  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(items));
  }, [items]);

  // Add item to cart
  const addItem = (product: Omit<CartItem, "quantity">) => {
    setItems((prevItems) => {
      // Check if the item with the same ID and size already exists
      const existingItemIndex = prevItems.findIndex(
        (item) => item.id === product.id && item.size === product.size
      );
      
      if (existingItemIndex >= 0) {
        // If it exists, increment quantity by 1
        const updatedItems = [...prevItems];
        updatedItems[existingItemIndex].quantity += 1;
        return updatedItems;
      } else {
        // If it doesn't exist, add new item with quantity 1
        return [...prevItems, { ...product, quantity: 1 }];
      }
    });
  };

  // Remove item from cart
  const removeItem = (id: string, size: string) => {
    setItems((prevItems) => 
      prevItems.filter((item) => !(item.id === id && item.size === size))
    );
  };

  // Update item quantity
  const updateQuantity = (id: string, size: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(id, size);
      return;
    }
    
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id && item.size === size
          ? { ...item, quantity }
          : item
      )
    );
  };

  // Clear cart
  const clearCart = () => {
    setItems([]);
  };

  // Calculate totals
  const totalItems = items.reduce((total, item) => total + item.quantity, 0);
  const totalPrice = items.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  // Checkout function
  const checkout = async (shippingDetails: ShippingDetails): Promise<boolean> => {
    try {
      // In a real app, this would be an API call to your payment processor
      
      // Create order in localStorage for demo purposes
      const ordersJson = localStorage.getItem("orders") || "[]";
      const orders = JSON.parse(ordersJson);
      
      const newOrder = {
        id: `order_${Date.now()}`,
        userId: user?.id || "guest",
        items: [...items],
        shippingDetails,
        total: totalPrice,
        status: "pending",
        createdAt: new Date().toISOString()
      };
      
      orders.push(newOrder);
      localStorage.setItem("orders", JSON.stringify(orders));
      
      // Send order notification email to site owner
      emailjs.send(
        "service_id", // Replace with your EmailJS service ID
        "template_id", // Replace with your EmailJS template ID
        {
          to_email: "boozersclub@yahoo.com",
          customer_name: shippingDetails.fullName,
          customer_email: shippingDetails.email,
          order_id: newOrder.id,
          order_details: items.map(item => `${item.name} (${item.size}) x${item.quantity}`).join(", "),
          total: `$${totalPrice.toFixed(2)}`,
          shipping_address: `${shippingDetails.address}, ${shippingDetails.city}, ${shippingDetails.state}, ${shippingDetails.postalCode}, ${shippingDetails.country}`,
          phone: shippingDetails.phone
        },
        "user_id" // Replace with your EmailJS user ID
      ).catch((err) => console.error("Failed to send order email:", err));
      
      // Clear the cart after successful order
      clearCart();
      
      return true;
    } catch (error) {
      console.error("Checkout error:", error);
      return false;
    }
  };

  const value = {
    items,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    totalItems,
    totalPrice,
    checkout,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

// Create a custom hook to use the cart context
export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};
