
import React, { createContext, useContext, useState, useEffect } from "react";
import emailjs from "emailjs-com";

// Define the types
type User = {
  id: string;
  name: string;
  email: string;
  address?: string;
  phone?: string;
};

type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateUserProfile: (data: Partial<User>) => void;
};

// Create the context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Create a provider component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Load user from localStorage on initial render
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
  }, []);

  // Login function
  const login = async (email: string, password: string): Promise<boolean> => {
    // In a real app, this would be an API call to your authentication service
    try {
      // For demo purposes, check if user exists in localStorage
      const usersJson = localStorage.getItem("users") || "[]";
      const users = JSON.parse(usersJson);
      
      const foundUser = users.find(
        (u: any) => u.email === email && u.password === password
      );
      
      if (foundUser) {
        // Remove password from user object before storing in state
        const { password, ...userWithoutPassword } = foundUser;
        setUser(userWithoutPassword);
        setIsAuthenticated(true);
        
        // Save to local storage
        localStorage.setItem("user", JSON.stringify(userWithoutPassword));
        return true;
      }
      return false;
    } catch (error) {
      console.error("Login error:", error);
      return false;
    }
  };

  // Register function
  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      // For demo purposes, store user in localStorage
      const usersJson = localStorage.getItem("users") || "[]";
      const users = JSON.parse(usersJson);
      
      // Check if user already exists
      if (users.some((u: any) => u.email === email)) {
        return false;
      }
      
      const newUser = {
        id: `user_${Date.now()}`,
        name,
        email,
        password, // In production, this would be hashed!
        createdAt: new Date().toISOString()
      };
      
      users.push(newUser);
      localStorage.setItem("users", JSON.stringify(users));
      
      // Remove password before storing in state
      const { password: _, ...userWithoutPassword } = newUser;
      setUser(userWithoutPassword);
      setIsAuthenticated(true);
      
      // Save authenticated user to localStorage
      localStorage.setItem("user", JSON.stringify(userWithoutPassword));
      
      // Send registration notification email to site owner
      emailjs.send(
        "service_id", // Replace with your EmailJS service ID
        "template_id", // Replace with your EmailJS template ID
        {
          to_email: "boozersclub@yahoo.com",
          user_name: name,
          user_email: email,
          message: `New user registration: ${name} (${email}) has registered on Boozer's Club.`,
        },
        "user_id" // Replace with your EmailJS user ID
      ).catch((err) => console.error("Failed to send notification email:", err));
      
      return true;
    } catch (error) {
      console.error("Registration error:", error);
      return false;
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem("user");
  };

  // Update user profile
  const updateUserProfile = (data: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...data };
      setUser(updatedUser);
      localStorage.setItem("user", JSON.stringify(updatedUser));
      
      // Also update in the users array
      const usersJson = localStorage.getItem("users") || "[]";
      const users = JSON.parse(usersJson);
      const updatedUsers = users.map((u: any) => 
        u.id === user.id ? { ...u, ...data } : u
      );
      localStorage.setItem("users", JSON.stringify(updatedUsers));
    }
  };

  const value = {
    user,
    isAuthenticated,
    login,
    register,
    logout,
    updateUserProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Create a custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
